let shopItemsData = [
  {
    id: "jfhgbvnscs",
    name: "Gloves",
    price: 1600,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "src/gloves.jpg",
  },
  {
    id: "ioytrhndcv",
    name: "Jacket",
    price: 3000,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "src/jacket.jpeg",
  },
  {
    id: "wuefbncxbsn",
    name: "T Shirt",
    price: 1500,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "src/shirt.jpg",
  },
  {
    id: "thyfhcbcv",
    name: "Wrestling helmet",
    price: 7000,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "src/helmet.jpg",
  },
];
