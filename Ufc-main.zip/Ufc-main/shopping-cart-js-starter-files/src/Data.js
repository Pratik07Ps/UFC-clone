let shopItemsData = [
  {
    id: "jfhgbvnscs",
    name: "Gloves",
    price: 1600,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "images/gloves.jpg",
  },
  {
    id: "ioytrhndcv",
    name: "Jacket",
    price: 3000,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "images/jacket.jpeg",
  },
  {
    id: "wuefbncxbsn",
    name: "T Shirt",
    price: 1500,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "images/shirt.jpg",
  },
  {
    id: "thyfhcbcv",
    name: "Wrestling helmet",
    price: 7000,
    desc: "Lorem ipsum dolor sit amet consectetur adipisicing.",
    img: "images/helmet.jpg",
  },
];
